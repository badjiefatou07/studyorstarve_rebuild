# StudyOrStarve Rebuild

This is a basic static recreation of StudyOrStarve.com.
Deploy using GitHub Pages or Netlify.